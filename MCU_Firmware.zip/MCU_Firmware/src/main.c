/*******************************************************************************
  Main Source File

  Company:
    Microchip Technology Inc.

  File Name:
    main.c

  Summary:
    This file contains the "main" function for a project.

  Description:
    This file contains the "main" function for a project.  The
    "main" function calls the "SYS_Initialize" function to initialize the state
    machines of all modules in the system
 *******************************************************************************/

// *****************************************************************************
// *****************************************************************************
// Section: Included Files
// *****************************************************************************
// *****************************************************************************

#include <stddef.h>                     // Defines NULL
#include <stdbool.h>                    // Defines true
#include <stdlib.h>                     // Defines EXIT_FAILURE
#include "definitions.h"                // SYS function prototypes
#include "../SPI_Test_Project.X/SPI_Display.h"
#include "../SPI_Test_Project.X/PWM_Generation.h"
#include "../SPI_Test_Project.X/Buttons.h"
#include "../SPI_Test_Project.X/Globals.h"
#include "../SPI_Test_Project.X/Encoders.h"
#include "../SPI_Test_Project.X/Globals.h"
#include "../SPI_Test_Project.X/UART.h"

// *****************************************************************************
// *****************************************************************************
// Section: Main Entry Point
// *****************************************************************************
// *****************************************************************************


volatile bool displayNeedsUpdate = false;
volatile bool PWMNeedsUpdate = true;
volatile bool UART_isActive = false;
volatile bool EXT_Mode_Activated = false;


int main ( void )
{
    /* Initialize all modules */
    SYS_Initialize ( NULL );
    
    __builtin_enable_interrupts(); 
    initializeButtons();
    initializeDisplay();
    encoderInitialize();
    
    matching(10000, 0.5);
    PWMGEN();
    
    update_display(_frequency, _duty, mode, isExternal);
        
    encoderHandler();
    

    
    while ( true )
    {
        /* Maintain state machines of all polled MPLAB Harmony modules. */
        SYS_Tasks ( );

        if(displayNeedsUpdate == true){
            update_display(_frequency, _duty, mode, isExternal);
            displayNeedsUpdate = false;
            
        }
        
        if (PWMNeedsUpdate == true)
        {
            PWMNeedsUpdate = false;
            PWMGEN();
        }

        
        if ((ic2_new_measurement == true) & (EXT_Mode_Activated == true))
        {
            ic2_new_measurement = false;

            uint32_t period_ticks = ic2_rise2 - ic2_rise1;
            uint32_t high_ticks   = ic2_fall - ic2_rise1;

            float tmr4_freq = 100000000.0f;
            _frequency = tmr4_freq / period_ticks;
            _duty = (high_ticks * 100.0f) / period_ticks;

            PWMNeedsUpdate = true;
        }
        
        UART_Task();
        
        if(UART_isActive == true){
            UART_Task();
        }
      
    }

    /* Execution should not come here during normal operation */

    return ( EXIT_FAILURE );
}


/*******************************************************************************
 End of File
*/

