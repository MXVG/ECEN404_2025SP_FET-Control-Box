/* 
 * File:   InputCapture.h
 * Author: MX
 *
 * Created on April 15, 2025, 3:03 PM
 */

#ifndef INPUTCAPTURE_H
#define	INPUTCAPTURE_H

#ifdef	__cplusplus
extern "C" {
#endif

#include <stdint.h>
#include <stdbool.h>

void PWM_Capture_Initialize(void);  // Call once in main
bool PWM_Capture_Get(float* frequency, float* duty_cycle);  // Returns true if new values are ready
static void ICAP2_Callback(uintptr_t context);

#ifdef	__cplusplus
}
#endif

#endif	/* INPUTCAPTURE_H */

