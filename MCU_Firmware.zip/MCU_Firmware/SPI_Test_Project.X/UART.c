#include <string.h>
#include <stdio.h>
#include <stddef.h>                     // Defines NULL
#include <stdbool.h>                    // Defines true
#include <stdlib.h>                     // Defines EXIT_FAILURE
#include "definitions.h" 
#include "../SPI_Test_Project.X/UART.h"
#include "Globals.h"

static char uartRxBuffer[UART_BUFFER_SIZE];   // Circular buffer for incoming data
static char commandQueue[COMMAND_QUEUE_SIZE][UART_BUFFER_SIZE]; // Queue for completed commands
static size_t bufferIndex = 0;
static size_t queueHead = 0; // Queue head for adding commands
static size_t queueTail = 0; // Queue tail for processing commands


void UART_Task(void)
{
    char receivedChar;//recieved character buffer
    while (UART6_Read(&receivedChar, 1)) // Check if data is available
    {
        if (receivedChar == '*') // End of a command
        {
            uartRxBuffer[bufferIndex] = '\0'; // Null-terminate the string
            if (!IsQueueFull())              // Add to the queue if space is available
            {
                AddToQueue(uartRxBuffer);
            }
            bufferIndex = 0; // Reset buffer for next command
        }
        else
        {
            // Add character to buffer if space allows
            if (bufferIndex < UART_BUFFER_SIZE - 1)
            {
                uartRxBuffer[bufferIndex++] = receivedChar;
            }
        }
    }

    ProcessQueue(); // Process completed commands in the queue
}

// Check if the command queue is empty
bool IsQueueEmpty(void)
{
    return queueHead == queueTail;
}

// Check if the command queue is full
bool IsQueueFull(void)
{
    return ((queueHead + 1) % COMMAND_QUEUE_SIZE) == queueTail;
}

// Add a command to the queue
void AddToQueue(const char *command)
{
    strcpy(commandQueue[queueHead], command);
    queueHead = (queueHead + 1) % COMMAND_QUEUE_SIZE;
}

// Process commands in the queue
void ProcessQueue(void)
{
    while (!IsQueueEmpty())
    {
        ProcessCommand(commandQueue[queueTail]);
        queueTail = (queueTail + 1) % COMMAND_QUEUE_SIZE;
    }
}

// Process a single command
void ProcessCommand(const char *data)
{
    char command[UART_BUFFER_SIZE];//holds command
    char number[UART_BUFFER_SIZE];//holds number
    double numValue;// holds number as a double
    //UART6_Write(" 1 ", sizeof(" 1 "));
   
    memset(command, 0, sizeof(command)); //makes sure command is clear
    memset(number, 0, sizeof(number));//makes sure number is clear
   
    SplitCommand(data, command, number); // call to split the command into number and command parts
    //UART6_Write("2 ", sizeof("2 "));
   
    numValue = strtod(number, NULL); //takes the number char string and makes it a double
    sprintf(number, "%f", numValue); // takes the number and puts into into number as a string (mainly this is for writing purposes)
    numValue = strtod(number, NULL);
   
    //execute the command
    //commands(command, numValue);
    while (UART6_WriteIsBusy());
    //UART6_Write(command, sizeof(command));
    //while (UART6_WriteIsBusy());
    //UART6_Write(" at ", sizeof(" at "));
   
    if (strstr(command, "mode")){//checks for if a command was called, and executes the changes
        modeIndex = (int)numValue;// calls function to set the new mode
    }
    if (strstr(command, "external")){//using external signal
        isExternal = true;
    }
    if (strstr(command, "freq")){//frequency command
        
        _frequency = numValue;
        PWMNeedsUpdate = true;
        
    }
    if (strstr(command, "duty")){//seting duty cycle
        _duty = numValue;
        PWMNeedsUpdate = true;
    }
}

// Split the input data into command and number
void SplitCommand(const char *data, char *command, char *number)
{
    const char *delimiter = ":"; // : is what i seperate the command by
   
    memset(command, 0, UART_BUFFER_SIZE); //make sure command and number are clear (nothing in them))
    memset(number, 0, UART_BUFFER_SIZE);
   
    char *token = strtok((char *)data, delimiter); // check if : is in the string

    if (token != NULL) // if there is : in the string
    {
        strcpy(command, token); // First part is the command

        token = strtok(NULL, delimiter); //take second part of command
        if (token != NULL)
        {
            strcpy(number, token); // Second part is the number
        }
    }
}