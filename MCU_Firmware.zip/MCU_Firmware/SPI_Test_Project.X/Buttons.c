#include "../SPI_Test_Project.X/Buttons.h"
#include "macros.h"
#include "definitions.h"                // SYS function prototypes
#include "peripheral/coretimer/plib_coretimer.h"
#include "../SPI_Test_Project.X/Globals.h"
#include "../SPI_Test_Project.X/SPI_Display.h"

static uint32_t lastSW1PressTime = 0;
static uint32_t lastSW2PressTime = 0;


int debounce(uint32_t lastPressTime){
    uint32_t now = CORETIMER_CounterGet();

    if ((now - lastPressTime) < (200 * TICKS_PER_MS)) {
        return -1;  // debounce: ignore if less than 200ms since last press
    }

    lastPressTime = now;
    return lastPressTime;
}

void MODE_BUTTON_User_Handler(GPIO_PIN pin, uintptr_t context)
{
    if(debounce(lastSW1PressTime) == -1){
        return;
    }

    if (MODE_BUTTON_Get() == SWITCH_PRESSED_STATE)
    {
        currSwitchPressedState = SWITCH_1;

        if (prevSwitchPressedState == currSwitchPressedState)
        {

            modeIndex = (modeIndex + 1) % modeCount;
            strncpy(mode, modes[modeIndex], sizeof(mode) - 1);
            mode[sizeof(mode) - 1] = '\0';

            displayNeedsUpdate = true;  // Set the flag
            PWMNeedsUpdate = true;
        }

        prevSwitchPressedState = SWITCH_1;
    }
}

void EXT_BUTTTON_User_Handler(GPIO_PIN pin, uintptr_t context)
{
    
    if(debounce(lastSW2PressTime) == -1){
        return;
    }
    
    if(EXT_BUTTON_Get() == SWITCH_PRESSED_STATE)
    {
        
        EXT_Mode_Activated = !EXT_Mode_Activated;
    
    }
}



void initializeButtons(){
    GPIO_PinInterruptCallbackRegister(MODE_BUTTON_PIN, MODE_BUTTON_User_Handler, 0);
    GPIO_PinInterruptEnable(MODE_BUTTON_PIN);
    //GPIO_PinInterruptCallbackRegister(SW2_PIN, SW2_User_Handler, 0);
    //GPIO_PinInterruptEnable(SW2_PIN);
    //GPIO_PinInterruptCallbackRegister(SW3_PIN, SW3_User_Handler, 0);
    //GPIO_PinInterruptEnable(SW3_PIN);
}

