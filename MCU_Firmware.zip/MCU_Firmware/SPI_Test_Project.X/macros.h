/* 
 * File:   macros.h
 * Author: MX
 *
 * Created on March 31, 2025, 10:49 PM
 */

#ifndef MACROS_H
#define	MACROS_H

#ifdef	__cplusplus
extern "C" {
#endif

#define SYS_FREQ 200000000 // Running at 200MHz


#ifdef	__cplusplus
}
#endif

#endif	/* MACROS_H */

