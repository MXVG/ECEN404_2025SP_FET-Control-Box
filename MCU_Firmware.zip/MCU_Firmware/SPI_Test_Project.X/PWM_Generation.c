#include <string.h>
#include <stdio.h>
#include <stddef.h>                     // Defines NULL
#include <stdbool.h>                    // Defines true
#include <stdlib.h>                     // Defines EXIT_FAILURE
#include "definitions.h"                // SYS function prototypes
#include "../SPI_Test_Project.X/PWM_Generation.h"
#include "../SPI_Test_Project.X/macros.h"

double _frequency = 10000;
double _duty = 0.5;
char mode[16] = "MATCH";
int modeIndex = 0;
const char *modes[] = {
    "MATCH", "COMP", "ALT"
};
const int modeCount = sizeof(modes) / sizeof(modes[0]);

bool isExternal = false;

void matching (double freq, double duty){
    // Calculate timer period for each PWM signal
    double period = (CPU_CLOCK_FREQUENCY/(16*freq)) - 1;  
   
    // Configure OC1 for PWM mode
    OC1CON = 0;                // Turn off OC1 while configuring
    OC1R = period * duty;        // Set duty cycle for PWM1
    OC1RS = (period * duty);       // Set duty cycle register for PWM1
    OC1CONbits.OCM = 0b110;   // PWM mode, fault pin disabled
    OC1CONbits.ON = 1;         // Turn on OC1
   
    OC2CON = 0;
    OC2CONbits.OCTSEL = 0;
    OC2CONbits.OCM = 0b110; // PWM mode (no fault pin)
    OC2RS = period * duty;        // Set PWM duty cycle (50% as an example)
    OC2R = (period*duty);     // Set phase for OC2 to be 0 (this can be adjusted for 180-degree phase shift)
    OC2CONbits.ON = 1;      // Enable OC2

    // Configure Timer2 for PWM frequency
    T2CON = 0;                       // Stop the timer and clear the control register
    T2CONbits.TCKPS = 0b011;   // Set prescaler to 1:256
    PR2 = (CPU_CLOCK_FREQUENCY / (16*freq)) - 1;     // Base period for Timer 2
    TMR2 = 0;                           // Clear the timer register
    TMR2_Start();                 // Start Timer2
   
}


void alternating (double freq, double duty){
    // Calculate timer period for each PWM signal
    double period = (CPU_CLOCK_FREQUENCY/(16*freq)) - 1;
   
    // Configure Timer2 (Single Timer for Both PWMs)
    T2CON = 0;
    T2CONbits.TCKPS = 0b011;  // Prescaler 1:8
    PR2 = period;  // Set Timer2 period
    TMR2 = 0;  // Reset Timer2
   
    T3CON = 0;
    T3CONbits.TCKPS = 0b011;  // Prescaler 1:8
    PR3 = period;  // Set Timer3 period
    TMR3 = period*(1-duty);  // Reset Timer3
   
    TMR2_Start();  // Start Timer2
    TMR3_Start(); // start timer3

    // Configure OC1 (First PWM Signal)
    OC1CON = 0;
    OC1R = 0;  // Start at the beginning of the cycle
    OC1RS = (period * duty);  // Set duty cycle
    OC1CONbits.OCM = 0b110;  // Edge-aligned PWM mode
    OC1CONbits.ON = 1;

    // Configure OC2 (Second PWM Signal with 180� Phase Shift)
    OC2CON = 0;
    OC2R = 0;  
    OC2RS = ((period)*(1-duty));  // Maintain same duty\ cycle but shifted
    OC2CONbits.OCM = 0b110;  // Edge-aligned PWM mode
    OC2CONbits.OCTSEL = 1;//select timer 3
    OC2CONbits.ON = 1;  
     

}

void complementary (double freq, double duty){
    // Calculate timer period for each PWM signal
    double period = (CPU_CLOCK_FREQUENCY/(16*freq)) - 1;
   
    // Configure Timer2 (Single Timer for Both PWMs)
    T2CON = 0;
    T2CONbits.TCKPS = 0b011;  // Prescaler 1:8
    PR2 = period;  // Set Timer2 period
    TMR2 = 0;  // Reset Timer2
   
    T3CON = 0;
    T3CONbits.TCKPS = 0b011;  // Prescaler 1:8
    PR3 = period;  // Set Timer3 period
    TMR3 = (period*(1-duty));  // Reset Timer3
   
    TMR2_Start();  // Start Timer2
    TMR3_Start(); // start timer3

    // Configure OC1 (First PWM Signal)
    OC1CON = 0;
    OC1R = 0;  // Start at the beginning of the cycle
    OC1RS = (period * duty);  // Set duty cycle
    OC1CONbits.OCM = 0b110;  // Edge-aligned PWM mode
    OC1CONbits.ON = 1;

    // Configure OC2 (Second PWM Signal with 180� Phase Shift)
    OC2CON = 0;
    OC2R = 0;
    OC2RS = ((period)*(1-duty))-20;  // Maintain same duty\ cycle but shifted
    OC2CONbits.OCM = 0b110;  // Edge-aligned PWM mode
    OC2CONbits.OCTSEL = 1;//select timer 3
    OC2CONbits.ON = 1;  
   
}


void PWMGEN(void)
{
    if (strcmp(mode, "MATCH") == 0)
    {
        matching(_frequency, _duty);
    }
    else if (strcmp(mode, "ALT") == 0)
    {
        alternating(_frequency, _duty);
    }
    else if (strcmp(mode, "COMP") == 0)
    {
        complementary(_frequency, _duty);
    }
    else
    {
        // Default to MATCH if the mode string is unknown
        matching(_frequency, _duty);
    }
}