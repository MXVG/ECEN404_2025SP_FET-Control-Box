/* 
 * File:   Encoders.h
 * Author: MX
 *
 * Created on April 1, 2025, 12:55 AM
 */

#ifndef ENCODERS_H
#define	ENCODERS_H

#ifdef	__cplusplus
extern "C" {
#endif


    void encoderInitialize(void);
    void encoderHandler(void);

#ifdef	__cplusplus
}
#endif

#endif	/* ENCODERS_H */

