#include "InputCapture.h"
#include "Globals.h"
#include "definitions.h"

// Timer frequency
#define TIMER4_FREQ_HZ 100000000.0f

volatile uint32_t ic2_rise1 = 0;
volatile uint32_t ic2_fall  = 0;
volatile uint32_t ic2_rise2 = 0;
volatile bool ic2_new_measurement = false;

void PWM_Capture_Initialize(void)
{

    ICAP2_CallbackRegister(ICAP2_Callback, 0);
    ICAP2_Enable();
}

// Callback registered with Harmony ICAP2 driver
static void ICAP2_Callback(uintptr_t context)
{
    static uint8_t state = 0;
    uint32_t timestamp = ICAP2_CaptureBufferRead();

    switch (state)
    {
        case 0: ic2_rise1 = timestamp; state = 1; break;
        case 1: ic2_fall  = timestamp; state = 2; break;
        case 2: ic2_rise2 = timestamp; ic2_new_measurement = true; state = 0; break;
    }
}


bool PWM_Capture_Get(float* frequency, float* duty_cycle)
{
    if (!ic2_new_measurement)
        return false;

    ic2_new_measurement = false;

    uint32_t period_ticks = (ic2_rise2 >= ic2_rise1) ? (ic2_rise2 - ic2_rise1) : (0xFFFFFFFF - ic2_rise1 + ic2_rise2 + 1);
    uint32_t high_ticks   = (ic2_fall  >= ic2_rise1) ? (ic2_fall - ic2_rise1)  : (0xFFFFFFFF - ic2_rise1 + ic2_fall  + 1);

    if (period_ticks == 0)
        return false;

    *frequency   = TIMER4_FREQ_HZ / period_ticks;
    *duty_cycle  = (high_ticks * 100.0f) / period_ticks;

    return true;
}
