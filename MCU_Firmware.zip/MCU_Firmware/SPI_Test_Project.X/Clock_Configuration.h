/* 
 * File:   Clock_Configuration.h
 * Author: MX
 *
 * Created on March 31, 2025, 10:48 PM
 */

#ifndef CLOCK_CONFIGURATION_H
#define	CLOCK_CONFIGURATION_H

#ifdef	__cplusplus
extern "C" {
#endif




#ifdef	__cplusplus
}
#endif

#endif	/* CLOCK_CONFIGURATION_H */

