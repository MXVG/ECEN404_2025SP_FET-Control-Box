/* 
 * File:   UART.h
 * Author: MX
 *
 * Created on April 21, 2025, 12:51 AM
 */

#ifndef UART_H
#define	UART_H

#ifdef	__cplusplus
extern "C" {
#endif

#define UART_BUFFER_SIZE 128
#define COMMAND_QUEUE_SIZE 10
    
void ProcessCommand(const char *data);
void SplitCommand(const char *data, char *command, char *number);
bool IsQueueEmpty(void);
bool IsQueueFull(void);
void AddToQueue(const char *command);
void ProcessQueue(void);
void UART_Task(void);


#ifdef	__cplusplus
}
#endif

#endif	/* UART_H */

